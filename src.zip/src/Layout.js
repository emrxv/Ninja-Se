export const layout = {
    score: { 
        position: "absolute",
        left:500,
        top:20,
        color:"black",
        width:150,
      },

    text: { 
        position: "absolute",
        left:500,
        top:50,
        color:"black",
        width:150,
      },

      victory: { 
        position: "absolute",
        left:500,
        top:90,
        color:"black",
        width:150,
      },

      scaling: { 
        position: "absolute",
        left: 40,
        top: 0,
      },

    buttons: { 
        position: "absolute",
        left: 300,
        top:90,
      },

      Config1:  {
        position: "absolute",
        left: 280,
        top: 20
      },

      Config2:  {
        position: "absolute",
        left: 350,
        top: 20
      },

      Config3:  {
        position: "absolute",
        left: 420,
        top: 20
      },

      Reset:  {
        position: "absolute",
        left: 350,
        top: 90
      },

      Remove:  {
        position: "absolute",
        left: 344,
        top: 120
      },
      
      upbutton:  {
        position: "absolute",
        left: 60,
        top: 70
      },
      
      downbutton : {
        position: "absolute",
        left: 47,
        top: 130,
      },
      
      leftbutton : {
        position: "absolute",
        top: 100,
      },
      
      rightbutton : {
        position: "absolute",
        top: 100,
        left: 100,
      },

}